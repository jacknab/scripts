#!/bin/bash

# MySQL credentials
DB_USER="root"
DB_PASS="1825Logan305!"
DB_NAME="pools"

# NOMP directory path
NOMP_DIR="/root/root/node-open-mining-portal"
POOL_CONFIGS_DIR="$NOMP_DIR/pool_configs"
LOG_FILE="/root/switch_pool.log"

# Function to log messages
log_message() {
    echo "$(date) - $1" >> $LOG_FILE
    echo "$1"
}

# Query MySQL to get the pool_id with the oldest timestamp and is not disabled
pool_id=$(mysql -u$DB_USER -p$DB_PASS -D$DB_NAME -se "SELECT pool_id FROM scrypt WHERE Disabled = 0 ORDER BY timestamp LIMIT 1;")
if [ -z "$pool_id" ]; then
    log_message "No active pool found in the database."
    exit 1
fi

log_message "Selected pool_id: $pool_id"

# Update the timestamp for the selected pool_id to current timestamp
mysql -u$DB_USER -p$DB_PASS -D$DB_NAME -se "UPDATE scrypt SET timestamp = NOW() WHERE pool_id = $pool_id;"
if [ $? -ne 0 ]; then
    log_message "Error updating the timestamp in the database."
    exit 1
fi

# Define the source directory for the pool configuration files based on pool_id
SOURCE_DIR="/root/root/$pool_id"
if [ ! -d "$SOURCE_DIR" ]; then
    log_message "Directory for pool $pool_id does not exist."
    exit 1
fi

# Clear the pool_configs directory
log_message "Clearing pool_configs directory..."
rm -rf $POOL_CONFIGS_DIR/*
if [ $? -ne 0 ]; then
    log_message "Error clearing pool_configs directory."
    exit 1
fi

# Copy all files from the source directory to the pool_configs directory
log_message "Copying files from $SOURCE_DIR to $POOL_CONFIGS_DIR..."
cp -r $SOURCE_DIR/* $POOL_CONFIGS_DIR/
if [ $? -eq 0 ]; then
    log_message "Configuration files copied successfully."
else
    log_message "Error copying the configuration files."
    exit 1
fi

# Function to run random tasks during pauses
run_random_task() {
    # Example of random commands to execute (you can modify these)
    log_message "Running a random task"

    # Check system uptime
    uptime > /dev/null
    sleep 1

    # Check memory usage
    free -m > /dev/null
    sleep 1

    # List contents of /tmp
    ls /tmp > /dev/null
    sleep 1

    # Ping localhost
    ping -c 1 localhost > /dev/null
    sleep 1

    # Check date/time
    date > /dev/null
    sleep 1
}

# Stop NOMP without checks or logging
log_message "Stopping NOMP..."
pkill -f "node init.js"

# Random tasks during pause before running the new script
run_random_task
sleep 10 # Pause for 10 seconds before running the next command

# Run node init.js for the new setup
log_message "Running node init.js from /root/root/node-mining-portal"
cd /root/root/node-mining-portal
node init.js
if [ $? -eq 0 ]; then
    log_message "Node init.js started successfully."
else
    log_message "Error starting node init.js."
    exit 1
fi

log_message "Script complete."
