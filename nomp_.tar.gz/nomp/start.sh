#!/bin/bash
cd ~
cd /root/root/node-mining-portal
node init.js

